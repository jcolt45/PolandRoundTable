

#------------------------------------------------------------------------------
# Function for getting all org custom metrics for a given graph.
# Uses affiliation_dates (filtered to start and end) to create graph
# on_cols determines what categories create edges

org_edge_scores_all <- function(affils_by_date,
                                on_cols        = c("Org.ID"),
                                start_date     = "1945-01-01",
                                end_date       = "1989-12-01",
                                all_orgs       = NULL) {

  month_seq <- seq.Date(ymd(start_date), ymd(end_date), by = "month")

  map_dfr(month_seq, ~ org_edge_scores_month(
    affils_by_date = affils_by_date,
    on_cols        = on_cols,
    month_start    = .x,
    all_orgs       = all_orgs))
}



org_edge_scores_month <- function(affils_by_date,
                                  on_cols,
                                  month_start,
                                  all_orgs = NULL) {

  month_start <- ymd(month_start)
  month_end   <- month_start %m+% months(1) - days(1)

  edgelist <- get_edgelist_members(
    affils_by_date, on_cols,
    start = month_start, end = month_end
  )
  if (nrow(edgelist) == 0) return(tibble())      # nothing this month

  # ------------------------------------------------------------------
  g <- graph_from_data_frame(edgelist, directed = FALSE)

  map_aff <- affils_by_date |>
    distinct(Member.ID, RT.Affiliation)

  V(g)$faction <- map_aff$RT.Affiliation[match(V(g)$name,
                                               map_aff$Member.ID)]

  E(g)$eb_std   <- edge_betweenness(g, weights = NA)

  E(g)$eb_cross <- cross_edge_betweenness(
    g,
    gov_idx = which(V(g)$faction == "Government"),
    opp_idx = which(V(g)$faction == "Opposition"))

  E(g)$eb_direct_cross <- direct_cross_edge_score(
    g,
    gov_idx = which(V(g)$faction == "Government"),
    opp_idx = which(V(g)$faction == "Opposition"))


  edge_tbl <- as_data_frame(g, what = "edges") |>
    bind_cols(E(g)[[]])

  # --- 1. who is present and their members  -------------------------
  members <- affils_by_date |>
    filter(Start.Date <= month_end, End.Date >= month_start) |>
    select(Member.ID, Org.ID)

  # one row per org that *really* appears this month
  member_lists <- members |>
    group_by(Org.ID) |>
    summarise(org_members = list(Member.ID), .groups = "drop")

  # --- 2. add orgs forced in by `all_orgs` --------------------------
  org_frame <- tibble(Org.ID = all_orgs %||% member_lists$Org.ID) |>
    left_join(member_lists, by = "Org.ID") |>
    mutate(org_members = replace_na(org_members,
                                    list(character(0))))

  # --- 3. compute scores -------------------------------------------
  org_scores <- org_frame |>
    mutate(
      present = lengths(org_members) > 0,

      EB_month_std   = map_dbl(org_members, ~{
        if (length(.x) == 0) return(NA_real_)
        idx <- edge_tbl$from %in% .x & edge_tbl$to %in% .x
        if (!any(idx)) 0 else sum(edge_tbl$eb_std[idx])
      }),

      EB_month_cross = map_dbl(org_members, ~{
        if (length(.x) == 0) return(NA_real_)
        idx <- edge_tbl$from %in% .x & edge_tbl$to %in% .x
        if (!any(idx)) 0 else sum(edge_tbl$eb_cross[idx])
      }),

      EB_month_direct_cross = map_dbl(org_members, ~{
        if (length(.x) == 0) return(NA_real_)
        idx <- edge_tbl$from %in% .x & edge_tbl$to %in% .x
        if (!any(idx)) 0 else sum(edge_tbl$eb_direct_cross[idx])
      })
    ) |>
    select(-org_members, -present) |>
    mutate(Start.Date = month_start,
           End.Date   = month_end)

  org_scores
}

#------------------------------------------------------------------------------
# Helper function for getting cross edge betweenness

cross_edge_betweenness <- function(g, gov_idx, opp_idx) {
  m <- ecount(g)
  eb <- numeric(m)

  if (length(gov_idx) == 0 || length(opp_idx) == 0)
    return(eb)

  for (s in gov_idx) {
    sp <- shortest_paths(g, from = s, to = opp_idx,
                         weights = NA, output = "epath")

    for (path in sp$epath) {
      if (length(path) == 0) next
      w <- 1 / length(path)
      eb[path] <- eb[path] + w
    }
  }
  eb
}

#------------------------------------------------------------------------------
# Helper function for getting cross edge betweenness (DIRECT CONNECTIONS ONLY)

direct_cross_edge_score <- function(g, gov_idx, opp_idx) {
  m <- ecount(g)
  eb_direct_cross <- numeric(m)

  if (length(gov_idx) == 0 || length(opp_idx) == 0)
    return(eb_direct_cross)

  for (i in seq_len(m)) {
    edge_ends <- ends(g, i, names = FALSE)
    v1 <- edge_ends[1]
    v2 <- edge_ends[2]

    if ((v1 %in% gov_idx && v2 %in% opp_idx) ||
        (v1 %in% opp_idx && v2 %in% gov_idx)) {
      eb_direct_cross[i] <- 1
    }
  }

  eb_direct_cross
}
